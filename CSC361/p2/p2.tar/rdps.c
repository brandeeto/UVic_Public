/*
* CSC 361: P2 (Client) 
* Author: Brandon Harvey
* Student ID: V00784918
*/

// Libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <time.h>
#include <regex.h>
#include <fcntl.h>
#include <unistd.h>

// Globals
#define PACKETSIZE 1024
#define HEADERSIZE 46
#define DATASIZE 978

#define TIMEOUT_SECONDS 0
#define TIMEOUT_MILISECS 500000

void print_log(char *event_type, char *_magic_, char *_type_, int _seqno_, int _ackno_, int _length_, int _window_, char *client_ip, int client_port, char *server_ip, int server_port){
  // set the time for logging
  struct timeval tv;
  time_t nowtime;
  struct tm *nowtm;
  char tmbuf[64], buf[64];

  gettimeofday(&tv, NULL);
  nowtime = tv.tv_sec;
  nowtm = localtime(&nowtime);
  strftime(tmbuf, sizeof tmbuf, "%H:%M:%S", nowtm);
  sprintf(buf, "%s.%06ld", tmbuf, tv.tv_usec);
  printf("%s %s %s:%d %s:%d %s %d/%d %d/%d\n", buf, event_type, client_ip, client_port, server_ip, server_port, _type_, _seqno_, _ackno_, _length_, _window_);
}

char * fill_header(char *_magic_, char *_type_, int _seqno_, int _ackno_, int _length_, int _window_, char *packet_to_send){
  // Send the packet back over containing the modified header
  // Dump the header struct contents into a buffer to be sent over the network
  memset(packet_to_send, 0, PACKETSIZE);
  int index = 0;
  index += sprintf(packet_to_send+index, "%s", "CSc361");
  index += sprintf(packet_to_send+index, "%s", "|");
  index += sprintf(packet_to_send+index, "%s", _type_);
  index += sprintf(packet_to_send+index, "%s", "|");
  index += sprintf(packet_to_send+index, "%d", _seqno_);
  index += sprintf(packet_to_send+index, "%s", "|");
  index += sprintf(packet_to_send+index, "%d", _ackno_);
  index += sprintf(packet_to_send+index, "%s", "|");
  index += sprintf(packet_to_send+index, "%d", _length_);
  index += sprintf(packet_to_send+index, "%s", "|");
  index += sprintf(packet_to_send+index, "%d", _window_);
  index += sprintf(packet_to_send+index, "%s", "|");
  return packet_to_send;
}

void print_stats(int total_data_bytes_sent, int unique_data_bytes_sent, int total_data_packets_sent, int unique_data_packets_sent, int syn_sent, int fin_sent, int rst_sent, int ack_received, int rst_received, struct timeval start){
  printf("total data bytes sent: %d\n", total_data_bytes_sent);
  printf("unique data bytes sent: %d\n", unique_data_bytes_sent);
  printf("total data packets sent: %d\n", total_data_packets_sent);
  printf("unique data packets sent: %d\n", unique_data_packets_sent);
  printf("SYN packets sent: %d\n", syn_sent);
  printf("FIN packets sent: %d\n", fin_sent);
  printf("RST packets sent: %d\n", rst_sent);
  printf("ACK packets received: %d\n", ack_received);
  printf("RST packets received: %d\n", rst_received);
  struct timeval end;
  gettimeofday(&end, NULL);
  double elapsed = ((end.tv_sec - start.tv_sec) * 1000) + (end.tv_usec / 1000 - start.tv_usec / 1000);
  printf("total time duration (second): %1.3f\n", elapsed / 1000);
}

int main(int argc, char *argv[]){
  // start execution time counter
  struct timeval start;
  gettimeofday(&start, NULL);
  // vars
  struct timeval killer;
	struct sockaddr_in server, client;
	int client_seq_no, socket_id, server_port, client_port, connection, server_len, client_len, bytes_received, file_sent;
  char packet_to_send[PACKETSIZE], packet_recv[PACKETSIZE], text_to_send[DATASIZE], *sender_filename, *server_ip, *client_ip, *event_type;
  char ch;
  int first_ack = 1;
  int timeout_count = 0;
  // counters
  int total_data_bytes_sent = 0;
  int unique_data_bytes_sent = 0;
  int total_data_packets_sent = 0;
  int unique_data_packets_sent = 0; 
  int syn_sent = 0; 
  int fin_sent = 0; 
  int rst_sent = 0;
  int ack_received = 0;
  int rst_received = 0;
  FILE *fp;

  // Header Default
  char *_magic_ = "CSc361";
  char *_type_ = "SYN";
  srand(time(NULL));
  int _seqno_ = rand() % 999999999;
  int _ackno_ = 0;
  int _length_ = 0;
  int _window_ = 0;
	
	// Argument handler
	if (argc != 6){
		printf("Usage: ./rdps <sender_ip> <sender_port> <receiver_ip> <receiver_port> <sender_filename>\n");
		return -1;
	}
  server_ip = argv[3];
  client_ip = argv[1];
	server_port = atoi(argv[4]);
	client_port = atoi(argv[2]);
  sender_filename = argv[5];

	// Create the socket with error checking
    if ((socket_id = socket (AF_INET, SOCK_DGRAM, 0)) == -1){
        perror("RDPS: An error occured during socket creation");
        return -1;
	}

	// Fill out the server struct
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(argv[1]);
	server.sin_port = htons(server_port);

	// Fill out the client struct
	memset(&client, 0, sizeof(client));
	client.sin_family = AF_INET;
	client.sin_addr.s_addr = inet_addr(argv[3]);
	client.sin_port = htons(client_port);

	// Bind the socket
	if (bind(socket_id, (struct sockaddr *) &server, sizeof(server)) < 0){
		close(socket_id);
        perror("RDPS: Couldn't bind socket!\n");
        return -1;
    }

  // Prep the file for reading
  fp = fopen(sender_filename, "r");

  while(1){
    memset(packet_recv, 0, PACKETSIZE);
    // Dump the header struct contents into a buffer to be sent over the network
    int index = 0;
    index += sprintf(packet_to_send+index, "%s", "CSc361");
    index += sprintf(packet_to_send+index, "%s", "|");
    index += sprintf(packet_to_send+index, "%s", _type_);
    char *resend_type = _type_;
    index += sprintf(packet_to_send+index, "%s", "|");
    index += sprintf(packet_to_send+index, "%d", _seqno_);
    int resend_seq = _seqno_;
    index += sprintf(packet_to_send+index, "%s", "|");
    index += sprintf(packet_to_send+index, "%d", _ackno_);
    int resend_ackno = _ackno_;
    index += sprintf(packet_to_send+index, "%s", "|");
    index += sprintf(packet_to_send+index, "%d", _length_);
    int resend_length = _length_;
    index += sprintf(packet_to_send+index, "%s", "|");
    index += sprintf(packet_to_send+index, "%d", _window_);
    int resend_window = _window_;
    index += sprintf(packet_to_send+index, "%s", "|");
    // If we're sending data, append the text to be sent
    if(strcmp(_type_, "DAT") == 0 && _window_ > 0){
      index += sprintf(packet_to_send+index, "%s", text_to_send);
    }
    memset(text_to_send, 0, DATASIZE);

    // Send the packet
    client_len = sizeof(client);
    if (sendto(socket_id, packet_to_send, PACKETSIZE, 0, (struct sockaddr *) &client, client_len) == -1){
      perror("RDPS: Error during packet send");
    }else{
      print_log("s", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
      if(strcmp(_type_, "DAT") == 0){
        total_data_bytes_sent += _length_;
        total_data_packets_sent += 1;
        unique_data_bytes_sent += _length_;
        unique_data_packets_sent += 1;
      }else if(strcmp(_type_, "SYN") == 0){
        syn_sent += 1;
      }
    }

    // Non-blocking receive
    while(1){
      start: memset(packet_recv, 0, PACKETSIZE);
      fd_set readset;
      int result, iof = -1;
      struct timeval killer;

      killer.tv_sec = TIMEOUT_SECONDS;
      killer.tv_usec = TIMEOUT_MILISECS;

      FD_ZERO(&readset);
      FD_SET(socket_id, &readset);

      int socket_action = select(socket_id+1, &readset, NULL, NULL, &killer);
      //printf("socket_action == %d\n", socket_action);
      if(socket_action == -1){
        perror("RDPS: error on select()");
      }else if(socket_action > 0){
        //set non-blocking mode
        if((iof = fcntl(socket_id, F_GETFL, 0)) != -1){
          fcntl(socket_id, F_SETFL, iof | O_NONBLOCK);
        }
        // receive
        if((bytes_received = recvfrom(socket_id, packet_recv, PACKETSIZE, MSG_DONTWAIT, (struct sockaddr *) &server, &server_len)) >= 1){
        }
        // set as before
        if(iof != -1){
          fcntl(socket_id, F_SETFL, iof);
        }

        // Dump the received packet_recv contents into separate variables
        // if we can tokenize that means we have a valid packet, else we'll need to timeout
        //printf("parsing the packet_recv: %s\n", packet_recv);
        char *token = strtok(packet_recv, "|");
        if(token){
          int count = 0;
          while(token){
            if(count == 0){
              _magic_ = token;
              //printf("_magic_ == %s\n", _magic_);
            }else if(count == 1){
              _type_ = token;
              //printf("_type_ == %s\n", _type_);
            }else if(count == 2){
              _seqno_ = atoi(token);
              //printf("_seqno_ == %d\n", _seqno_);
            }else if(count == 3){
              _ackno_ = atoi(token);
              //printf("_ackno_ == %d\n", _ackno_);
            }else if(count == 4){
              _length_ = atoi(token);
              //printf("_length_ == %d\n", _length_);
            }else if(count == 5){
              _window_ = atoi(token);
              //printf("_window_ == %d\n", _window_);
            }
            token = strtok(0, "|");
            count++;
          }
          timeout_count = 0;
        }
        // if the client_seq_no == _seqno_ sent back we'll need to resend the packet as the
        // server is ACKing the wrong packet
        if((resend_seq == _seqno_) && (first_ack == 0)){
          //printf("resending DAT\n");
          print_log("R", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
          if(strcmp(_type_, "ACK") == 0){
            ack_received += 1;
          }else if(strcmp(_type_, "RST") == 0){
            rst_received += 1;
          }
          goto resend;
        }else{
          print_log("r", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
          if(strcmp(_type_, "ACK") == 0){
            ack_received += 1;
          }else if(strcmp(_type_, "RST") == 0){
            rst_received += 1;
          }
          break;
        }
      }else if(socket_action == 0 && (_window_ > 0 || first_ack == 1)){
        // Handle a timeout
        // send it again, try 3 times, if fails send RST
        // Send the packet
        resend: client_len = sizeof(client);
        if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
          perror("RDPS: Error during packet send");
        }else{
          print_log("S", "CSc361", resend_type, resend_seq, resend_ackno, resend_length, resend_window, client_ip, client_port, server_ip, server_port);
          if(strcmp(resend_type, "DAT") == 0){
            total_data_bytes_sent += resend_length;
            total_data_packets_sent += 1;
          }else if(strcmp(resend_type, "SYN") == 0){
            syn_sent += 1;
          }
        }
        timeout_count++;
        // failed to send 3 times, sending RST and closing connection
        if(timeout_count == 2){
          _length_ = 0;
          _type_ = "RST";
          fill_header("CSc361", _type_, _seqno_, _ackno_, _length_, _window_, packet_to_send);
          client_len = sizeof(client);
          //printf("SENDING 3: %s\n", packet_to_send);
          if(sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
            perror("RDPS: Error during packet send");
          }else{
            print_log("s", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
            rst_sent += 1;
          }
          close(socket_id);
          fclose(fp);
          print_stats(total_data_bytes_sent, unique_data_bytes_sent, total_data_packets_sent, unique_data_packets_sent, syn_sent, fin_sent, rst_sent, ack_received, rst_received, start);
          return 1;
        }
      }
    }

    memset(packet_to_send, 0, PACKETSIZE);

    // Packet type handler
    if((strcmp(_type_, "ACK") == 0) && (first_ack == 1)){
      client_seq_no = _seqno_;
      _seqno_ = _ackno_+1;
      _ackno_ = client_seq_no+1;
      first_ack = 0;
      _type_ = "DAT";
    }else if((strcmp(_type_, "ACK") == 0) && (first_ack == 0) && (file_sent != 1)){
      client_seq_no = _seqno_;
      _seqno_ = _ackno_;
      _seqno_ = client_seq_no;
      _type_ = "DAT";
    }else if(strcmp(_type_, "RST") == 0){
      fclose(fp);
      close(socket_id);
      print_stats(total_data_bytes_sent, unique_data_bytes_sent, total_data_packets_sent, unique_data_packets_sent, syn_sent, fin_sent, rst_sent, ack_received, rst_received, start);
      return 1;
    }

    // While the EOF hasn't been reached, read in a char at a time, appending it to text_to_send
    // once the buffer has been filled, send it off, clear the buffer and continue until EOF
    if(fp == NULL){
      printf("ERROR: Unable to open %s\n", sender_filename);
    }
    // If the file transfer isn't complete continue, else initiate connection close
    if(file_sent == 0){
      if(_window_ > 0){
        int index = 0;
        memset(text_to_send, 0, DATASIZE);
        while(1){
          ch = fgetc(fp);
          if(feof(fp)){
            // the entire file has been sent, initiate connection close after packet sent
            file_sent = 1;
            _length_ = index;
            break;
          }else if(index == _window_){
            // the entire file hasn't been sent
            text_to_send[index] = ch;
            file_sent = 0;
            _length_ = index;
            break;
          }else if(index == DATASIZE+1){
            text_to_send[index] = ch;
            file_sent = 0;
            _length_ = index;
            break;
          }
          text_to_send[index] = ch;
          index++;
        }
      }
    }else{
      // transfer complete, close down the connection
      // fill the header with updated values
      fill_header("CSc361", "FIN", _seqno_+1, _ackno_, _length_, _window_, packet_to_send);
      resend_type = "FIN";
      resend_seq = _seqno_;
      resend_ackno = _ackno_;
      resend_length = _length_;
      resend_window = _window_;
      client_len = sizeof(client);
      //printf("SENDING 4: %s\n", packet_to_send);
      if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
        perror("RDPS: Error during packet send");
      }else{
        print_log("s", "CSc361", "FIN", _seqno_+1, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
        fin_sent += 1;
      }

      // wait for ACK with timeout
      // Non-blocking receive
      while(1){
        start2: memset(packet_recv, 0, PACKETSIZE);
        fd_set readset;
        int result, iof = -1;
        struct timeval killer;

        killer.tv_sec = TIMEOUT_SECONDS;
        killer.tv_usec = TIMEOUT_MILISECS;

        FD_ZERO(&readset);
        FD_SET(socket_id, &readset);

        int socket_action = select(socket_id+1, &readset, NULL, NULL, &killer);
        if(socket_action == -1){
          perror("RDPS: error on select()");
        }else if(socket_action > 0){
          //set non-blocking mode
          if((iof = fcntl(socket_id, F_GETFL, 0)) != -1){
            fcntl(socket_id, F_SETFL, iof | O_NONBLOCK);
          }
          // receive
          if((bytes_received = recvfrom(socket_id, packet_recv, PACKETSIZE, MSG_DONTWAIT, (struct sockaddr *) &server, &server_len)) >= 1){
            // Dump the received packet_recv contents into separate variables
            // if we can tokenize that means we have a valid packet, else we'll need to timeout
            //printf("parsing the packet_recv: %s\n", packet_recv);
            char *token = strtok(packet_recv, "|");
            if(token){
              int count = 0;
              while(token){
                if(count == 0){
                  _magic_ = token;
                  //printf("_magic_ == %s\n", _magic_);
                }else if(count == 1){
                  _type_ = token;
                  //printf("_type_ == %s\n", _type_);
                }else if(count == 2){
                  _seqno_ = atoi(token);
                  //printf("_seqno_ == %d\n", _seqno_);
                }else if(count == 3){
                  _ackno_ = atoi(token);
                  //printf("_ackno_ == %d\n", _ackno_);
                }else if(count == 4){
                  _length_ = atoi(token);
                  //printf("_length_ == %d\n", _length_);
                }else if(count == 5){
                  _window_ = atoi(token);
                  //printf("_window_ == %d\n", _window_);
                }
                token = strtok(0, "|");
                count++;
              }
              timeout_count = 0;
            }
            // if the resend_seq == _seqno_ sent back we'll need to resend the packet as the
            // server is ACKing the wrong packet
            if((resend_seq == _seqno_) && (first_ack == 0)){
              //printf("resending DAT\n");
              print_log("R", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
              if(strcmp(_type_, "ACK") == 0){
                ack_received += 1;
              }else if(strcmp(_type_, "RST") == 0){
                rst_received += 1;
              }
              goto resend2;
            }else{
              print_log("r", "CSc361", _type_, _seqno_, _ackno_, _length_, _window_, client_ip, client_port, server_ip, server_port);
              if(strcmp(_type_, "ACK") == 0){
                ack_received += 1;
              }else if(strcmp(_type_, "RST") == 0){
                rst_received += 1;
              }
              // close the connection
              fclose(fp);
              close(socket_id);
              print_stats(total_data_bytes_sent, unique_data_bytes_sent, total_data_packets_sent, unique_data_packets_sent, syn_sent, fin_sent, rst_sent, ack_received, rst_received, start);
              return 0;
            }
          }
        }else if(socket_action == 0 && _window_ > 0){
          // Handle a timeout
          // send it again, try 3 times, if fails send RST
          resend2: client_len = sizeof(client);
          //printf("SENDING 5: %s\n", packet_to_send);
          if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
            perror("RDPS: Error during packet send");
          }else{
            print_log("S", "CSc361", resend_type, resend_seq, resend_ackno, resend_length, resend_window, client_ip, client_port, server_ip, server_port);
            fin_sent += 1;
          }
          timeout_count++;
          // failed to send 3 times, closing connection
          if(timeout_count == 2){
            close(socket_id);
            fclose(fp);
            print_stats(total_data_bytes_sent, unique_data_bytes_sent, total_data_packets_sent, unique_data_packets_sent, syn_sent, fin_sent, rst_sent, ack_received, rst_received, start);
            return 1;
          }
        }
      }
      // close the connection
      fclose(fp);
      close(socket_id);
      print_stats(total_data_bytes_sent, unique_data_bytes_sent, total_data_packets_sent, unique_data_packets_sent, syn_sent, fin_sent, rst_sent, ack_received, rst_received, start);
      return 0;
    }
  }
	return 0;	
}
