/*
* CSC 361: P2 (Server) 
* Author: Brandon Harvey
* Student ID: V00784918
*/

// Libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <time.h>
#include <regex.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <inttypes.h>

// Globals
#define PACKETSIZE 1024
#define HEADERSIZE 46
#define DATASIZE 978
#define SLIDINGWINDOW 4096

#define TIMEOUT_SECONDS 0
#define TIMEOUT_MILISECS 500000

void print_log(char *event_type, char *_magic_, char *_type_, int _seqno_, int _ackno_, int _length_, int _window_, struct sockaddr_in client, struct sockaddr_in server){
  // set the time for logging
  struct timeval tv;
  time_t nowtime;
  struct tm *nowtm;
  char tmbuf[64], buf[64];

  gettimeofday(&tv, NULL);
  nowtime = tv.tv_sec;
  nowtm = localtime(&nowtime);
  strftime(tmbuf, sizeof tmbuf, "%H:%M:%S", nowtm);
  sprintf(buf, "%s.%06ld", tmbuf, tv.tv_usec);
  
  printf("%s %s %s:%d %s:%d %s %d/%d %d/%d\n", buf, event_type, inet_ntoa(server.sin_addr), ntohs(server.sin_port), inet_ntoa(client.sin_addr), ntohs(client.sin_port), _type_, _seqno_, _ackno_, _length_, _window_);
}

char * fill_header(char *_magic_, char *_type_, int _seqno_, int _ackno_, int _length_, int _window_, char *packet_to_send){
	// Send the packet back over containing the modified header
	// Dump the header struct contents into a buffer to be sent over the network
	memset(packet_to_send, 0, PACKETSIZE);
	int index = 0;
	index += sprintf(packet_to_send+index, "%s", _magic_);
	index += sprintf(packet_to_send+index, "%s", "|");
	index += sprintf(packet_to_send+index, "%s", _type_);
	index += sprintf(packet_to_send+index, "%s", "|");
	index += sprintf(packet_to_send+index, "%d", _seqno_);
	index += sprintf(packet_to_send+index, "%s", "|");
	index += sprintf(packet_to_send+index, "%d", _ackno_);
	index += sprintf(packet_to_send+index, "%s", "|");
	index += sprintf(packet_to_send+index, "%d", _length_);
	index += sprintf(packet_to_send+index, "%s", "|");
	index += sprintf(packet_to_send+index, "%d", _window_);
	index += sprintf(packet_to_send+index, "%s", "|");
	return packet_to_send;
}

void print_stats(int total_data_bytes_received, int unique_data_bytes_received, int total_data_packets_received, int unique_data_packets_received, int syn_received, int fin_received, int rst_received, int ack_sent, int rst_sent, struct timeval start){
  printf("total data bytes received: %d\n", total_data_bytes_received);
  printf("unique data bytes received: %d\n", unique_data_bytes_received);
  printf("total data packets received: %d\n", total_data_packets_received);
  printf("unique data packets received: %d\n", unique_data_packets_received);
  printf("SYN packets received: %d\n", syn_received);
  printf("FIN packets received: %d\n", fin_received);
  printf("RST packets received: %d\n", rst_received);
  printf("ACK packets sent: %d\n", ack_sent);
  printf("RST packets sent: %d\n", rst_sent);
  struct timeval end;
  gettimeofday(&end, NULL);
  double elapsed = ((end.tv_sec - start.tv_sec) * 1000) + (end.tv_usec / 1000 - start.tv_usec / 1000);
  printf("total time duration (second): %1.3f\n", elapsed / 1000);
}


int main(int argc, char *argv[]){
	// start execution time counter
  	struct timeval start;
  	gettimeofday(&start, NULL);
	// vars
	char text_recv[DATASIZE], packet_recv[PACKETSIZE], packet_to_send[PACKETSIZE], *_magic_, *_type_, *receiver_filename;
	struct sockaddr_in server, client;
	int buf_index, socket_id, receiver_port, bytes_received, server_len, client_len, _seqno_, _ackno_, _length_, _window_, sliding_window, max_timeouts;
	int first_ack = 1;
	int timeout_count = 1;
	FILE *fp;
	char *data_buffer = malloc(sizeof(char) * SLIDINGWINDOW*2);
	// counters
	int total_data_bytes_received = 0;
	int unique_data_bytes_received = 0;
	int total_data_packets_received = 0;
	int unique_data_packets_received = 0; 
	int syn_received = 0; 
	int fin_received = 0; 
	int rst_received = 0;
	int ack_sent = 0;
	int rst_sent = 0;

	// Argument handler
	if (argc < 3){
		printf("Usage: ./rdpr <receiver_ip> <receiver_port> <receiver_filename>\n");
		return -1;
	}
	receiver_port = atoi(argv[2]);
	receiver_filename = argv[3];

	// Create the socket with error checking
    if ((socket_id = socket (AF_INET, SOCK_DGRAM, 0)) == -1){
		perror("An error occured during socket creation");
        return -1;
	}

	// Fill out the server struct
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(argv[1]);
	server.sin_port = htons(receiver_port);

	// Bind the socket
	if (bind(socket_id, (struct sockaddr *) &server, sizeof(server)) < 0){
		close(socket_id);
        perror("RDPS: Couldn't bind socket!\n");
        return -1;
    }

    fp = fopen(receiver_filename, "w");

    while(1){
    	char *resend_type = _type_;
    	int resend_seq = _seqno_;
    	int resend_ackno = _ackno_;
    	int resend_length = _length_;
    	int resend_window = _window_;
    	max_timeouts = 0;
	    // Receive the packet
	    client_len = sizeof(client);

	    // Non-blocking receive
    	while(1){
    		start: memset(packet_recv, 0, PACKETSIZE);
    		memset(text_recv, 0, DATASIZE);

	      	fd_set readset;
			int result, iof = -1;
		    struct timeval killer;

		    killer.tv_sec = TIMEOUT_SECONDS;
		    killer.tv_usec = TIMEOUT_MILISECS;
		    FD_ZERO(&readset);
		    FD_SET(socket_id, &readset);

		    int socket_action = select(socket_id+1, &readset, NULL, NULL, &killer);
		    if(socket_action == -1){
			    perror("RDPS: error on select()");
		    }else if(socket_action > 0){
		    	//set non-blocking mode
		        if((iof = fcntl(socket_id, F_GETFL, 0)) != -1){
		        	fcntl(socket_id, F_SETFL, iof | O_NONBLOCK);
		        }
		        // receive
		        if((bytes_received = recvfrom(socket_id, packet_recv, PACKETSIZE+1, MSG_DONTWAIT, (struct sockaddr *) &client, &client_len)) >= 1){
		        	// Dump the received packet_recv contents into separate variables
			        // set as before
			        if(iof != -1){
			        	fcntl(socket_id, F_SETFL, iof);
			        }

				    char *token = strtok(packet_recv, "|");
				    int count = 0;
				    while(token){
				    	if(count == 0){
				    		_magic_ = token;
				    	}else if(count == 1){
				    		_type_ = token;
				    	}else if(count == 2){
				    		_seqno_ = atoi(token);
				    	}else if(count == 3){
				    		_ackno_ = atoi(token);
				    	}else if(count == 4){
				    		_length_ = atoi(token);
				    	}else if(count == 5){
				    		_window_ = atoi(token);
				    	}else if(count == 6){
			        		sprintf(text_recv, "%s", token);
			      		}
				    	token = strtok(0, "|");
				    	count++;
				    }
				    timeout_count = 0;
			    }
			    // If the server seq is the same as the ack, the sender resent a packet because they never
			    // got our ACK, resend the ack and erase that packet
			    if((resend_seq == _ackno_) && (first_ack == 0) && (strcmp(_type_, "RST")) != 0){
			    	print_log("R", _magic_, _type_, _seqno_, _ackno_, _length_, _window_, client, server);
			    	if(strcmp(_type_, "DAT") == 0){
				    	total_data_packets_received += 1;
				    	total_data_bytes_received += _length_;
			    	}else if(strcmp(_type_, "SYN") == 0){
			    		syn_received += 1;
			    	}else if(strcmp(_type_, "FIN") == 0){
			    		fin_received += 1;
			    	}else if(strcmp(_type_, "RST") == 0){
			    		rst_received += 1;
			    	}
			    	goto resend;
			    }else{
			    	print_log("r", _magic_, _type_, _seqno_, _ackno_, _length_, _window_, client, server);
			   		if(strcmp(_type_, "DAT") == 0){
			   		total_data_packets_received += 1;
			   		total_data_bytes_received += _length_;
			   		unique_data_packets_received += 1;
			   		unique_data_bytes_received += _length_;
			    	}else if(strcmp(_type_, "SYN") == 0){
			    		syn_received += 1;
			    	}else if(strcmp(_type_, "FIN") == 0){
			    		fin_received += 1;
			    	}else if(strcmp(_type_, "RST") == 0){
			    		rst_received += 1;
			    	}
			   		break;
			    }
		    }else if((socket_action == 0) && (first_ack == 0)){
		      	resend: _magic_ = "CSc361";
		      	_type_ = "ACK";
		      	client_len = sizeof(client);
		      	if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
	            	perror("RDPS: Error during packet resend");
	          	}else{
					print_log("S", _magic_, resend_type, resend_seq, resend_ackno, resend_length, resend_window, client, server);
					ack_sent += 1;
				}

	          	timeout_count++;
	          	// failed to send 3 times, sending RST and closing connection
	          	if(timeout_count == 3){
	          	_magic_ = "CSc361";
	            _length_ = 0;
	            _type_ = "RST";
	           	_ackno_ = _seqno_ + 1;
		      	_seqno_ = _ackno_ + 1;

	            fill_header(_magic_, _type_, _seqno_, _ackno_, _length_, _window_, packet_to_send);
	            client_len = sizeof(client);
	            if(sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
	            	perror("RDPS: Error during packet rst send");
	            }else{
					print_log("s", _magic_, _type_, _seqno_, _ackno_, _length_, _window_, client, server);
	            	rst_sent += 1;
	            }

	            close(socket_id);
	            if(fp){
					fclose(fp);				
				}
				print_stats(total_data_bytes_received, unique_data_bytes_received, total_data_packets_received, unique_data_packets_received, syn_received, fin_received, rst_received, ack_sent, rst_sent, start);
	            return 1;
	          }
		    }
		}

		memset(packet_to_send, 0, PACKETSIZE);

		// If SYN
		if(strcmp(_type_, "SYN") == 0){
			srand(_ackno_);
			_ackno_ = _seqno_ + 1; 
			_seqno_ = rand() % 999999999;
			_window_ = SLIDINGWINDOW;
			_length_ = 0;
			_type_ = "ACK";

			// fill the header with updated values
			fill_header(_magic_, _type_, _seqno_, _ackno_, _length_, _window_, packet_to_send);
			
	  		if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
	    		perror("RDPR: Error during sync send");
			}
			print_log("s", _magic_, _type_, _seqno_, _ackno_, _length_, _window_, client, server);
			first_ack = 0;
			ack_sent += 1;
	  	}else if(strcmp(_type_, "FIN") == 0){
			// Send an ACK
			// dump the remaining data into the text file before connection closes
			fputs(data_buffer, fp);
			_window_ += sizeof(data_buffer);
			// fill the header with updated values
			_length_ = 0;
			fill_header(_magic_, "ACK", _seqno_, _ackno_, _length_, _window_, packet_to_send);
	  		if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
	    		perror("RDPR: Error during sync send");
			}
			print_log("s", _magic_, "ACK", _seqno_, _ackno_, _length_, _window_, client, server);
			ack_sent += 1;

			// Close the connections
			fclose(fp);				
			close(socket_id);
			// Print the stats
			print_stats(total_data_bytes_received, unique_data_bytes_received, total_data_packets_received, unique_data_packets_received, syn_received, fin_received, rst_received, ack_sent, rst_sent, start);
			return 0;
		}else if(strcmp(_type_, "RST") == 0){
			fclose(fp);
			close(socket_id);
			print_stats(total_data_bytes_received, unique_data_bytes_received, total_data_packets_received, unique_data_packets_received, syn_received, fin_received, rst_received, ack_sent, rst_sent, start);
	    	return 1;
    	}else if(strcmp(_type_, "DAT") == 0){
			// react to DAT, push the supplied text into our buffer, update the window size, ack that back,
			// and dump the buffer into the text file when window size is full or FIN is received
			int length_temp = _length_;
			int seqno_temp = _seqno_;
			_seqno_ = _ackno_;
			_ackno_ = seqno_temp + _length_;
			_window_ = _window_ - _length_;
			_type_ = "ACK";

			buf_index += sprintf(data_buffer+buf_index, "%s", text_recv);
			memset(text_recv, 0, DATASIZE);

			if(_window_ == 0){
				// Write to the file and adjust the window size accordingly
				if(fp == NULL){
					printf("Error opening %s for writing\n", receiver_filename);
					print_stats(total_data_bytes_received, unique_data_bytes_received, total_data_packets_received, unique_data_packets_received, syn_received, fin_received, rst_received, ack_sent, rst_sent, start);
					return 1;
				}else{
					fprintf(fp, "%s", data_buffer);
					_window_ += SLIDINGWINDOW;
					memset(data_buffer, 0, SLIDINGWINDOW);
					buf_index = 0;
				}
			}

			// fill the header with updated values
			_length_ = 0;
			fill_header(_magic_, _type_, _seqno_, _ackno_, _length_, _window_, packet_to_send);
	  		if (sendto(socket_id, packet_to_send, sizeof(packet_to_send), 0, (struct sockaddr *) &client, client_len) == -1){
	    		perror("RDPR: Error during window send");
			}
			print_log("s", _magic_, _type_, _seqno_, _ackno_, _length_, _window_, client, server);
	  		ack_sent += 1;
	  	}
	}
	fclose(fp);
	close(socket_id);
	print_stats(total_data_bytes_received, unique_data_bytes_received, total_data_packets_received, unique_data_packets_received, syn_received, fin_received, rst_received, ack_sent, rst_sent, start);
	return 0;
}