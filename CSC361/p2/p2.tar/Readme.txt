Student #: V00784918
Lab Section: B04

Description:
My RDP protocol ACK's back each time a packet is received. If a packet is out of order the protocol will resend a request for the expected packet, during which the receiver will recieve the request and resend the packet. Once the correct packet is obtained the out of order packet is dropped and replaced with the correct one.

If a packet is sent but is dropped by the network a timeout will occur, at this time the sender will resend the packet which it never got a response for. If this timeout and resend cycle occurs more than twice, the sender will send a RST packet and close the connection due to unrecoverable network issues.

My program continually reads and writes to the files, once the end of file has been reached the last DAT packet will be sent over and written to by the receiver. After the sender recieves an ACK for the previous DAT packet (the one containing the EOF) it'll send over a FIN; waiting for an ACK back. If an ACK is never received it'll resend the FIN up to 2 times before closing the connection.

My chosen window size is 4096 bytes.