Name: Brandon Harvey
Student ID: V00784918
Lab Section: B04

My main function contains the skeleton of my sws, including the majority of the variable initialization, cli argument parser, and the select statement. The select statement constantly polls for user input; if input is received it ensures that the input is equal to 'q', if so it will close all sockets, resources and exit gracefully. If no input is received it will loop through the send/receieve portion of the sws. During this the sws will poll for packets, if a packet is recieved it will pass the data to be parsed out and validated to ensure the request is valid. As soon as the request is validated it will attempt to execute, passing the content of the file back to the user.