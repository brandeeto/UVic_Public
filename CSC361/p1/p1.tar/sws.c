/*
* CSC 361: P1 (Simple Web Server) 
* Author: Brandon Harvey
* Student ID: V00784918
*/

// Libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <time.h>
#include <regex.h>
#include <fcntl.h>

// Globals
#define MAXBUFFERLENGTH 256

// Bind the socket
int bind_socket(int socket_id, int port_number, struct sockaddr_in serv_addr){
	// clear the struct
	bzero((char *) &serv_addr, sizeof(serv_addr));

	// Fill out the struct
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port_number);
	serv_addr.sin_addr.s_addr = INADDR_ANY;

	// Bind the socket using the newly created and filled out struct :D
	if (bind(socket_id, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
		close(socket_id);
		perror("SWS: Couldn't bind socket!\n");
		return -1;	
	}
	return 0;
}

/* Locates the requested file, returning it in chunks via sento(), will fail out if file cannot be found
*	or if the requested file isn't contained within the slave directory
*/
int file_puller(struct sockaddr_in cli_addr, int socket_id, char* file_requested, char * request, char * action, char * file, char * http_version, char * buf){
	// vars
	char ch;
	const char error_response[] = "HTTP/1.0 404 Not Found\r\n\r\n";
	const char good_response[] = "HTTP/1.0 200 OK\r\n\r\n";
	int count = 0;
	int cli_len;
	char data_to_send[MAXBUFFERLENGTH];
	cli_len = sizeof(cli_addr);

	FILE *fp;
	fp = fopen(file_requested, "r");
	// If the file fails to open throw 404
	if (fp == NULL){
		// send 404 Not Found response and a blank line
		if (sendto(socket_id, error_response, strlen(error_response), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
			perror("SWS: Error during sendto()");
		}
		// 404 server side logging
		printf("%s %s:%d %s %s %s; HTTP/1.0 404 Not Found\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version);
		return -1;
	}

	// send 200 OK response and a blank line
	if (sendto(socket_id, good_response, strlen(good_response), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
		perror("SWS: Error during sendto()");
	}

	// 200 server side logging
	printf("%s %s:%d %s %s %s; HTTP/1.0 200 OK; %s\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version, file_requested);

	// While the EOF hasn't been reached, read in a char at a time, appending it to data_to_send
	// once the buffer has been filled, send it off, clear the buffer and continue until EOF
	while(1){
		ch = fgetc(fp);
		if (feof(fp)){
			data_to_send[count] = '\0';
			if (sendto(socket_id, data_to_send, strlen(data_to_send), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
				perror("SWS: Error during sendto()");
			}
			break;
		}else if (count == 255){
			data_to_send[count+1] = '\0';
			if (sendto(socket_id, data_to_send, strlen(data_to_send), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
				perror("SWS: Error during sendto()");
			}
			bzero(data_to_send, MAXBUFFERLENGTH-1);
			count = 0;
		}
		data_to_send[count] = ch;
		count++;
	}

	fclose(fp);
	return 0;
}

// Parses the request string, performing error handling and dumps the values into an array
char* request_parser(char * request, char * slave_dir, char * file_requested, struct sockaddr_in cli_addr, int socket_id, char * action, char * file, char * http_version, char * buf){
	const char bad_request_resp[] = "HTTP/1.0 400 Bad Request\r\n\r\n";
	const char not_found_resp[] = "HTTP/1.0 404 Not Found\r\n\r\n";
	char *token;
	int cli_len, count = 0;
	cli_len = sizeof(cli_addr);
	regex_t forward_slash; //up_dir;

	// strip out the args
	while((token = strsep(&request, " ")) != NULL){
		if (count == 0){
			strcpy(action, token);
		}else if (count == 1){
			strcpy(file, token);
		}else if (count == 2){
			strcpy(http_version, token);
		}
		count++;		
	}

	// strip off hidden chars
	strtok(action, "\r\n");
	strtok(file, "\r\n");
	strtok(http_version, "\r\n");

	// If its not a GET request, fail out with error
	if ((strcmp(action, "GET") != 0) && (strcmp(action, "get") != 0)){
		if (sendto(socket_id, bad_request_resp, strlen(bad_request_resp), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
			perror("SWS: Error during sendto()");
		}
		printf("%s %s:%d %s %s %s; HTTP/1.0 400 Bad Request\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version);
		return "NULL";
	}

	// If its not the correct http version, fail out with error
	if ((strcmp(http_version, "HTTP/1.0") != 0) && (strcmp(http_version, "http/1.0") != 0)){
		if (sendto(socket_id, bad_request_resp, strlen(bad_request_resp), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
			perror("SWS: Error during sendto()");
		}
		printf("%s %s:%d %s %s %s; HTTP/1.0 400 Bad Request\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version);
		return "NULL";
	}

	// If the user requests '/' assume '/index.html'
	if (strcmp(file, "/") == 0){
		strcat(file, "index.html");
	}

	// throw 400 if user fails to provide a '/' for file path
	regcomp(&forward_slash, "^/.*", 0);
	int matched_slash = regexec(&forward_slash, file, 0, NULL, 0);
	if(matched_slash){
		if (sendto(socket_id, bad_request_resp, strlen(bad_request_resp), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
			perror("SWS: Error during sendto()");
		}
		printf("%s %s:%d %s %s %s; HTTP/1.0 400 Bad Request\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version);
		return "NULL";
	}

	// throw 404 if user attempts to pull from above directories
	char *up_dir = strstr(file, "..");
	if (up_dir){
		if (sendto(socket_id, not_found_resp, strlen(not_found_resp), 0, (struct sockaddr *) &cli_addr, cli_len) == -1){
			perror("SWS: Error during sendto()");
		}
		printf("%s %s:%d %s %s %s; HTTP/1.0 404 Not Found\n", buf, inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port), action, file, http_version);
		return "NULL";
	}

	strcpy(file_requested, slave_dir);
	strcat(file_requested, file);

	return file_requested;
}

int main(int argc, char *argv[]){
	// vars
	int socket_id, port_number, bytes_received, selected;
	struct sockaddr_in serv_addr, cli_addr;
	char buffer[MAXBUFFERLENGTH], file_requested[MAXBUFFERLENGTH], quit[1];
	char *slave_dir, action[MAXBUFFERLENGTH], file[MAXBUFFERLENGTH], http_version[MAXBUFFERLENGTH];
	struct timeval killer;

	// Test for the passed in args, if sufficient args provided create the socket with error handling
	if (argc < 3){
		printf("Error, port number or slave directory not provided\nUsage: %s <port> <slave_directory>\n", argv[0]);
		return -1;
	}else if (argc >= 3){
		printf("sws is running on UDP port %s serving %s\n", argv[1], argv[2]);
		printf("press 'q' to quit...\n");
		// Create the socket with error checking
		if ((socket_id = socket (AF_INET, SOCK_DGRAM, 0)) == -1){
			perror("An error occured during socket creation");
			return -1;
		}
	}

	// assign passed in args to variables
	port_number = atoi(argv[1]);
	slave_dir = argv[2];

	// socket has been successfully created at this point, now we must hand it down to bind
	bind_socket(socket_id, port_number, serv_addr);


	// socket is now bound to desired port, serving the requested slave directory
	// constantly loop over the listener, dump the request into a struct to handle later		
	while(1){
		// Time handler
		time_t timer;
		char buf[100];
		struct tm* tm_info;
		time(&timer);
		tm_info = localtime(&timer);
		strftime(buf, 100, "%b %d %X", tm_info);

		bzero(quit, 2);

		fd_set read_fds;
		killer.tv_sec = 1;
   		killer.tv_usec = 0;
		FD_ZERO( &read_fds );
		FD_SET( STDIN_FILENO, &read_fds );
		selected = select( socket_id, &read_fds, NULL, NULL, &killer);
		if (selected == -1){
			perror("SWS: error on select()");
			close(socket_id);
			return -1;
		}else if (selected == 0){
			// Receive request 
			bzero((char *) &cli_addr, sizeof(cli_addr));
			int bytes_received = 0, cli_len;
			cli_len = sizeof(cli_addr);
			bzero(buffer, MAXBUFFERLENGTH-1);
			if ((bytes_received = recvfrom(socket_id, buffer, MAXBUFFERLENGTH-1, MSG_DONTWAIT, (struct sockaddr *)&cli_addr, &cli_len)) >= 1){
				// zero and delimit the buffers
				buffer[bytes_received] = '\0';
				bzero(file_requested, MAXBUFFERLENGTH-1);
				bzero(action, MAXBUFFERLENGTH-1);
				bzero(file, MAXBUFFERLENGTH-1);
				bzero(http_version, MAXBUFFERLENGTH-1);

				// Parse and handle request
				char* file_to_pull = request_parser(buffer, slave_dir, file_requested, cli_addr, socket_id, action, file, http_version, buf);

				// If everything went well and we can pull a file, do it!
				if (strcmp(file_to_pull, "NULL") != 0){
					file_puller(cli_addr, socket_id, file_to_pull, buffer, action, file, http_version, buf);
				}
			}
		}else if (selected >= 1){
			scanf(" %c",quit);
			getchar();
			strtok(quit, "\r\n");
			if (strcmp(quit, "q") == 0){
				// free memory
				close(socket_id);
				break;
			}
		}
	}
	return 0;
}
